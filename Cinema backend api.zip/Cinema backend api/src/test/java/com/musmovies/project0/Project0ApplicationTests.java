package com.musmovies.project0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
